import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';

import '../services/auth_service.dart';
import '../services/call_service.dart';

class CallScreen extends StatefulWidget {
  final String roomId;
  final bool video, caller;
  const CallScreen({super.key, required this.roomId, required this.video, required this.caller});
  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  late final CallService _call;
  bool _ready = false, _muted = false, _camOff = false;

  @override
  void initState() {
    super.initState();
    _call = CallService(widget.roomId, video: widget.video);
    _init();
  }

  Future<void> _init() async {
    await [Permission.microphone, if (widget.video) Permission.camera].request();
    if (widget.caller) {
      await _call.start(AuthService.me.uid);
    } else {
      await _call.answer();
    }
    _call.ended.listen((e) {
      if (e && mounted) Navigator.pop(context);
    });
    if (mounted) setState(() => _ready = true);
  }

  @override
  void dispose() {
    _call.hangUp();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: !_ready
          ? const Center(child: Text('Connecting…'))
          : Stack(children: [
              Positioned.fill(
                child: widget.video
                    ? RTCVideoView(_call.remoteRenderer,
                        objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)
                    : const Center(child: Icon(Icons.person, size: 120)),
              ),
              if (widget.video)
                Positioned(
                  top: 48,
                  right: 16,
                  width: 100,
                  height: 150,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: RTCVideoView(_call.localRenderer, mirror: true),
                  ),
                ),
              Positioned(
                bottom: 40,
                left: 0,
                right: 0,
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  _btn(_muted ? Icons.mic_off : Icons.mic, () {
                    setState(() => _muted = !_muted);
                    _call.toggleMute(_muted);
                  }),
                  if (widget.video) ...[
                    _btn(_camOff ? Icons.videocam_off : Icons.videocam, () {
                      setState(() => _camOff = !_camOff);
                      _call.toggleCamera(_camOff);
                    }),
                    _btn(Icons.cameraswitch, _call.switchCamera),
                  ],
                  _btn(Icons.call_end, () => Navigator.pop(context), color: Colors.red),
                ]),
              ),
            ]),
    );
  }

  Widget _btn(IconData i, VoidCallback f, {Color? color}) => CircleAvatar(
        radius: 28,
        backgroundColor: color ?? Colors.white24,
        child: IconButton(icon: Icon(i, color: Colors.white), onPressed: f),
      );
}
