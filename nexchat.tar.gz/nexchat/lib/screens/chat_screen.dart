import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

import '../services/auth_service.dart';
import '../services/call_service.dart';
import '../services/chat_service.dart';
import 'call_screen.dart';

class ChatScreen extends StatefulWidget {
  final String roomId, title;
  final bool isDm;
  const ChatScreen({super.key, required this.roomId, required this.title, this.isDm = false});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  final _recorder = AudioRecorder();
  double? _progress;
  bool _recording = false;

  @override
  void initState() {
    super.initState();
    // Incoming call banner
    CallService.incoming(widget.roomId, ChatService.uid).listen((c) {
      if (c != null && mounted) _showIncoming(c['video'] == true);
    });
  }

  void _showIncoming(bool video) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text('Incoming ${video ? 'video' : 'voice'} call'),
        actions: [
          TextButton(
              onPressed: () {
                Navigator.pop(context);
                FirebaseFirestore.instance
                    .collection('rooms')
                    .doc(widget.roomId)
                    .collection('calls')
                    .doc('active')
                    .update({'ended': true});
              },
              child: const Text('Decline')),
          FilledButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => CallScreen(
                            roomId: widget.roomId, video: video, caller: false)));
              },
              child: const Text('Answer')),
        ],
      ),
    );
  }

  Future<void> _sendText() async {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    _text.clear();
    await ChatService.send(widget.roomId, text: t);
  }

  Future<void> _uploadAndSend(File f, String name, String type) async {
    setState(() => _progress = 0);
    try {
      final url = await ChatService.upload(widget.roomId, f, name,
          onProgress: (p) => setState(() => _progress = p));
      await ChatService.send(widget.roomId, type: type, url: url, fileName: name);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Upload failed: $e')));
      }
    } finally {
      if (mounted) setState(() => _progress = null);
    }
  }

  Future<void> _pickMedia(ImageSource src, {bool video = false}) async {
    final p = ImagePicker();
    final x = video
        ? await p.pickVideo(source: src)
        : await p.pickImage(source: src, imageQuality: 80, maxWidth: 1920);
    if (x != null) {
      await _uploadAndSend(File(x.path), x.name, video ? 'video' : 'image');
    }
  }

  Future<void> _pickFile() async {
    final r = await FilePicker.platform.pickFiles();
    if (r?.files.single.path != null) {
      final f = r!.files.single;
      await _uploadAndSend(File(f.path!), f.name, 'file');
    }
  }

  Future<void> _toggleRecord() async {
    if (_recording) {
      final path = await _recorder.stop();
      setState(() => _recording = false);
      if (path != null) await _uploadAndSend(File(path), 'voice.m4a', 'audio');
    } else {
      if (!await Permission.microphone.request().isGranted) return;
      final dir = await getTemporaryDirectory();
      await _recorder.start(const RecordConfig(),
          path: '${dir.path}/v_${DateTime.now().millisecondsSinceEpoch}.m4a');
      setState(() => _recording = true);
    }
  }

  void _attachMenu() => showModalBottomSheet(
        context: context,
        builder: (_) => SafeArea(
          child: Wrap(children: [
            ListTile(
                leading: const Icon(Icons.photo),
                title: const Text('Photo from gallery'),
                onTap: () {
                  Navigator.pop(context);
                  _pickMedia(ImageSource.gallery);
                }),
            ListTile(
                leading: const Icon(Icons.photo_camera),
                title: const Text('Take photo'),
                onTap: () {
                  Navigator.pop(context);
                  _pickMedia(ImageSource.camera);
                }),
            ListTile(
                leading: const Icon(Icons.video_library),
                title: const Text('Video'),
                onTap: () {
                  Navigator.pop(context);
                  _pickMedia(ImageSource.gallery, video: true);
                }),
            ListTile(
                leading: const Icon(Icons.attach_file),
                title: const Text('File'),
                onTap: () {
                  Navigator.pop(context);
                  _pickFile();
                }),
          ]),
        ),
      );

  void _call(bool video) => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) =>
              CallScreen(roomId: widget.roomId, video: video, caller: true)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: widget.isDm
            ? [
                IconButton(icon: const Icon(Icons.call), onPressed: () => _call(false)),
                IconButton(icon: const Icon(Icons.videocam), onPressed: () => _call(true)),
              ]
            : null,
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: ChatService.messages(widget.roomId),
            builder: (c, s) {
              if (!s.hasData) return const Center(child: CircularProgressIndicator());
              final docs = s.data!.docs;
              return ListView.builder(
                reverse: true,
                padding: const EdgeInsets.all(8),
                itemCount: docs.length,
                itemBuilder: (_, i) => _Bubble(
                  roomId: widget.roomId,
                  id: docs[i].id,
                  m: docs[i].data(),
                ),
              );
            },
          ),
        ),
        if (_progress != null) LinearProgressIndicator(value: _progress),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
            child: Row(children: [
              IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: _attachMenu),
              Expanded(
                child: TextField(
                  controller: _text,
                  minLines: 1,
                  maxLines: 5,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: InputDecoration(
                    hintText: _recording ? 'Recording… tap mic to send' : 'Message',
                    filled: true,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none),
                  ),
                  onSubmitted: (_) => _sendText(),
                ),
              ),
              IconButton(
                icon: Icon(_recording ? Icons.stop_circle : Icons.mic,
                    color: _recording ? Colors.redAccent : null),
                onPressed: _toggleRecord,
              ),
              IconButton(icon: const Icon(Icons.send), onPressed: _sendText),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _Bubble extends StatelessWidget {
  final String roomId, id;
  final Map<String, dynamic> m;
  const _Bubble({required this.roomId, required this.id, required this.m});

  @override
  Widget build(BuildContext context) {
    final mine = m['senderId'] == AuthService.me.uid;
    final cs = Theme.of(context).colorScheme;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _menu(context, mine),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 3),
          padding: const EdgeInsets.all(10),
          constraints:
              BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
          decoration: BoxDecoration(
            color: mine ? cs.primaryContainer : const Color(0xFF2B2D31),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (!mine)
              Text(m['senderName'] ?? '',
                  style: TextStyle(
                      fontWeight: FontWeight.bold, color: cs.primary, fontSize: 12)),
            _content(context),
            if ((m['reactions'] as Map?)?.isNotEmpty ?? false)
              Wrap(
                spacing: 4,
                children: (m['reactions'] as Map).entries
                    .map((e) => Chip(
                          visualDensity: VisualDensity.compact,
                          label: Text('${e.key} ${(e.value as List).length}'),
                        ))
                    .toList(),
              ),
          ]),
        ),
      ),
    );
  }

  Widget _content(BuildContext context) {
    final url = m['url'] as String?;
    switch (m['type']) {
      case 'image':
        return GestureDetector(
          onTap: () => showDialog(
              context: context,
              builder: (_) => Dialog(
                  child: InteractiveViewer(child: CachedNetworkImage(imageUrl: url!)))),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(
                imageUrl: url!,
                placeholder: (_, __) => const SizedBox(
                    height: 120, child: Center(child: CircularProgressIndicator()))),
          ),
        );
      case 'video':
        return _VideoPlayer(url: url!);
      case 'audio':
        return _AudioPlayer(url: url!);
      case 'file':
        return InkWell(
          onTap: () => launchUrl(Uri.parse(url!), mode: LaunchMode.externalApplication),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.insert_drive_file),
            const SizedBox(width: 8),
            Flexible(child: Text(m['fileName'] ?? 'File')),
            const SizedBox(width: 8),
            const Icon(Icons.download, size: 18),
          ]),
        );
      default:
        return SelectableText(m['text'] ?? '');
    }
  }

  void _menu(BuildContext context, bool mine) => showModalBottomSheet(
        context: context,
        builder: (_) => SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: ['👍', '❤️', '😂', '😮', '😢', '🔥']
                  .map((e) => TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                          ChatService.react(roomId, id, e);
                        },
                        child: Text(e, style: const TextStyle(fontSize: 26)),
                      ))
                  .toList(),
            ),
            if (mine)
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('Delete'),
                onTap: () {
                  Navigator.pop(context);
                  ChatService.deleteMessage(roomId, id);
                },
              ),
          ]),
        ),
      );
}

class _VideoPlayer extends StatefulWidget {
  final String url;
  const _VideoPlayer({required this.url});
  @override
  State<_VideoPlayer> createState() => _VideoPlayerState();
}

class _VideoPlayerState extends State<_VideoPlayer> {
  late final VideoPlayerController _c;
  bool _ready = false;
  @override
  void initState() {
    super.initState();
    _c = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) => mounted ? setState(() => _ready = true) : null);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return const SizedBox(height: 140, child: Center(child: CircularProgressIndicator()));
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Stack(alignment: Alignment.center, children: [
        AspectRatio(aspectRatio: _c.value.aspectRatio, child: VideoPlayer(_c)),
        IconButton(
          iconSize: 48,
          icon: Icon(_c.value.isPlaying ? Icons.pause_circle : Icons.play_circle),
          onPressed: () => setState(() => _c.value.isPlaying ? _c.pause() : _c.play()),
        ),
      ]),
    );
  }
}

class _AudioPlayer extends StatefulWidget {
  final String url;
  const _AudioPlayer({required this.url});
  @override
  State<_AudioPlayer> createState() => _AudioPlayerState();
}

class _AudioPlayerState extends State<_AudioPlayer> {
  final _p = AudioPlayer();
  bool _playing = false;
  @override
  void initState() {
    super.initState();
    _p.onPlayerComplete.listen((_) => setState(() => _playing = false));
  }

  @override
  void dispose() {
    _p.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(
          icon: Icon(_playing ? Icons.pause : Icons.play_arrow),
          onPressed: () async {
            if (_playing) {
              await _p.pause();
            } else {
              await _p.play(UrlSource(widget.url));
            }
            setState(() => _playing = !_playing);
          },
        ),
        const Text('Voice message'),
      ]);
}
