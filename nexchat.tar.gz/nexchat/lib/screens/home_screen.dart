import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import '../services/chat_service.dart';
import 'chat_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [const _ChatsTab(), const _ServersTab(), const _ProfileTab()];
    return Scaffold(
      body: SafeArea(child: pages[_tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.dns_outlined), label: 'Servers'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Me'),
        ],
      ),
    );
  }
}

// ---------------- Chats (DMs + groups) ----------------
class _ChatsTab extends StatelessWidget {
  const _ChatsTab();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chats'), actions: [
        IconButton(
          icon: const Icon(Icons.group_add_outlined),
          onPressed: () => _newGroup(context),
        ),
      ]),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _findUser(context),
        child: const Icon(Icons.edit_outlined),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: ChatService.myChats(),
        builder: (c, s) {
          if (s.hasError) return Center(child: Text('${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final docs = s.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text('No chats yet. Tap + to start one.'));
          }
          return ListView(
            children: docs.map((d) {
              final m = d.data();
              final isDm = m['type'] == 'dm';
              return ListTile(
                leading: CircleAvatar(
                    child: Icon(isDm ? Icons.person : Icons.group)),
                title: isDm
                    ? _DmName(members: List<String>.from(m['members']))
                    : Text(m['name'] ?? 'Group'),
                subtitle: Text(m['lastText'] ?? '',
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => ChatScreen(
                          roomId: d.id, title: m['name'] ?? 'Chat', isDm: isDm)),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }

  Future<void> _findUser(BuildContext context) async {
    final q = TextEditingController();
    List<Map<String, dynamic>> res = [];
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: EdgeInsets.fromLTRB(
              16, 16, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: q,
              decoration: const InputDecoration(
                  hintText: 'Search people by name (case-sensitive)',
                  prefixIcon: Icon(Icons.search)),
              onChanged: (v) async {
                if (v.trim().isEmpty) return;
                final r = await ChatService.searchUsers(v.trim());
                set(() => res = r);
              },
            ),
            ...res.map((u) => ListTile(
                  title: Text(u['name'] ?? ''),
                  subtitle: Text(u['status'] ?? ''),
                  onTap: () async {
                    final id = await ChatService.openDm(u['uid']);
                    if (ctx.mounted) {
                      Navigator.pop(ctx);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ChatScreen(
                                roomId: id, title: u['name'] ?? 'Chat', isDm: true)),
                      );
                    }
                  },
                )),
          ]),
        ),
      ),
    );
  }

  Future<void> _newGroup(BuildContext context) async {
    final name = await _ask(context, 'Group name');
    if (name == null || name.isEmpty) return;
    final id = await ChatService.createGroup(name, []);
    if (context.mounted) {
      Navigator.push(context,
          MaterialPageRoute(builder: (_) => ChatScreen(roomId: id, title: name)));
    }
  }
}

class _DmName extends StatelessWidget {
  final List<String> members;
  const _DmName({required this.members});
  @override
  Widget build(BuildContext context) {
    final other = members.firstWhere((m) => m != ChatService.uid, orElse: () => '');
    return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      future: FirebaseFirestore.instance.collection('users').doc(other).get(),
      builder: (_, s) => Text(s.data?.data()?['name'] ?? '...'),
    );
  }
}

// ---------------- Servers & channels ----------------
class _ServersTab extends StatelessWidget {
  const _ServersTab();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Servers'), actions: [
        IconButton(
          icon: const Icon(Icons.login),
          tooltip: 'Join with invite code',
          onPressed: () async {
            final code = await _ask(context, 'Invite code');
            if (code == null || code.isEmpty) return;
            final ok = await ChatService.joinServer(code);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(ok ? 'Joined!' : 'Invalid code')));
            }
          },
        ),
      ]),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final n = await _ask(context, 'Server name');
          if (n != null && n.isNotEmpty) await ChatService.createServer(n);
        },
        child: const Icon(Icons.add),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: ChatService.myServers(),
        builder: (c, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          if (s.data!.docs.isEmpty) {
            return const Center(child: Text('Create or join a server.'));
          }
          return ListView(
            children: s.data!.docs.map((d) {
              final m = d.data();
              return ExpansionTile(
                leading: CircleAvatar(
                    child: Text((m['name'] as String)[0].toUpperCase())),
                title: Text(m['name']),
                subtitle: Text('Invite: ${m['inviteCode']}  •  ${(m['members'] as List).length} members'),
                children: [
                  StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                    stream: ChatService.channels(d.id),
                    builder: (_, cs) => Column(
                      children: (cs.data?.docs ?? [])
                          .map((ch) => ListTile(
                                leading: const Icon(Icons.tag),
                                title: Text(ch['name']),
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => ChatScreen(
                                          roomId: ch.id, title: '# ${ch['name']}')),
                                ),
                              ))
                          .toList(),
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.add),
                    title: const Text('New channel'),
                    onTap: () async {
                      final n = await _ask(context, 'Channel name');
                      if (n != null && n.isNotEmpty) {
                        await ChatService.createChannel(d.id, n);
                      }
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.exit_to_app),
                    title: const Text('Leave server'),
                    onTap: () => ChatService.leaveServer(d.id),
                  ),
                ],
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

// ---------------- Profile ----------------
class _ProfileTab extends StatelessWidget {
  const _ProfileTab();

  @override
  Widget build(BuildContext context) {
    final u = AuthService.me;
    return Scaffold(
      appBar: AppBar(title: const Text('Me')),
      body: ListView(children: [
        const SizedBox(height: 24),
        Center(
          child: CircleAvatar(
            radius: 48,
            backgroundImage: u.photoURL != null ? NetworkImage(u.photoURL!) : null,
            child: u.photoURL == null ? const Icon(Icons.person, size: 48) : null,
          ),
        ),
        const SizedBox(height: 12),
        Center(
            child: Text(u.displayName ?? u.email ?? '',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
        Center(child: Text(u.email ?? '', style: const TextStyle(color: Colors.white60))),
        const SizedBox(height: 24),
        ListTile(
          leading: const Icon(Icons.edit),
          title: const Text('Change display name'),
          onTap: () async {
            final n = await _ask(context, 'Display name');
            if (n != null && n.isNotEmpty) {
              await u.updateDisplayName(n);
              await AuthService.updateProfile(name: n);
            }
          },
        ),
        ListTile(
          leading: const Icon(Icons.mood),
          title: const Text('Set status'),
          onTap: () async {
            final n = await _ask(context, 'Status');
            if (n != null) await AuthService.updateProfile(status: n);
          },
        ),
        const ListTile(
          leading: Icon(Icons.cloud_done_outlined),
          title: Text('Cloud sync is on'),
          subtitle: Text('Chats, files and servers are saved to your account. '
              'Log in on any device to get them back.'),
        ),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.redAccent),
          title: const Text('Log out'),
          onTap: AuthService.signOut,
        ),
      ]),
    );
  }
}

Future<String?> _ask(BuildContext context, String label) {
  final c = TextEditingController();
  return showDialog<String>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(label),
      content: TextField(controller: c, autofocus: true),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
            onPressed: () => Navigator.pop(context, c.text.trim()),
            child: const Text('OK')),
      ],
    ),
  );
}
