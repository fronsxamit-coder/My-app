import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

/// 1-to-1 voice/video calling. Signalling goes through Firestore:
///   rooms/{rid}/calls/active  { offer, answer, video, from, ended }
///   .../active/callerCandidates, .../active/calleeCandidates
class CallService {
  final String roomId;
  final bool video;
  CallService(this.roomId, {this.video = true});

  RTCPeerConnection? _pc;
  MediaStream? localStream;
  final remoteRenderer = RTCVideoRenderer();
  final localRenderer = RTCVideoRenderer();

  static const _config = {
    'iceServers': [
      {'urls': 'stun:stun.l.google.com:19302'},
      {'urls': 'stun:stun1.l.google.com:19302'},
      // Add a TURN server here for calls across strict networks.
    ]
  };

  DocumentReference<Map<String, dynamic>> get _doc => FirebaseFirestore.instance
      .collection('rooms')
      .doc(roomId)
      .collection('calls')
      .doc('active');

  Future<void> _setup() async {
    await remoteRenderer.initialize();
    await localRenderer.initialize();
    localStream = await navigator.mediaDevices.getUserMedia({
      'audio': true,
      'video': video ? {'facingMode': 'user'} : false,
    });
    localRenderer.srcObject = localStream;
    _pc = await createPeerConnection(_config);
    for (final t in localStream!.getTracks()) {
      await _pc!.addTrack(t, localStream!);
    }
    _pc!.onTrack = (e) {
      if (e.streams.isNotEmpty) remoteRenderer.srcObject = e.streams[0];
    };
  }

  /// Caller side.
  Future<void> start(String myUid) async {
    await _setup();
    final cand = _doc.collection('callerCandidates');
    _pc!.onIceCandidate = (c) => cand.add(c.toMap());
    final offer = await _pc!.createOffer();
    await _pc!.setLocalDescription(offer);
    await _doc.set({
      'offer': {'sdp': offer.sdp, 'type': offer.type},
      'video': video,
      'from': myUid,
      'ended': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
    _doc.snapshots().listen((s) async {
      final d = s.data();
      if (d?['answer'] != null && (await _pc?.getRemoteDescription()) == null) {
        await _pc!.setRemoteDescription(
            RTCSessionDescription(d!['answer']['sdp'], d['answer']['type']));
      }
    });
    _doc.collection('calleeCandidates').snapshots().listen((q) {
      for (final c in q.docChanges.where((c) => c.type == DocumentChangeType.added)) {
        final m = c.doc.data()!;
        _pc?.addCandidate(RTCIceCandidate(m['candidate'], m['sdpMid'], m['sdpMLineIndex']));
      }
    });
  }

  /// Callee side.
  Future<void> answer() async {
    await _setup();
    final cand = _doc.collection('calleeCandidates');
    _pc!.onIceCandidate = (c) => cand.add(c.toMap());
    final d = (await _doc.get()).data()!;
    await _pc!.setRemoteDescription(
        RTCSessionDescription(d['offer']['sdp'], d['offer']['type']));
    final ans = await _pc!.createAnswer();
    await _pc!.setLocalDescription(ans);
    await _doc.update({'answer': {'sdp': ans.sdp, 'type': ans.type}});
    _doc.collection('callerCandidates').snapshots().listen((q) {
      for (final c in q.docChanges.where((c) => c.type == DocumentChangeType.added)) {
        final m = c.doc.data()!;
        _pc?.addCandidate(RTCIceCandidate(m['candidate'], m['sdpMid'], m['sdpMLineIndex']));
      }
    });
  }

  Stream<bool> get ended =>
      _doc.snapshots().map((s) => s.data()?['ended'] == true);

  void toggleMute(bool mute) =>
      localStream?.getAudioTracks().forEach((t) => t.enabled = !mute);

  void toggleCamera(bool off) =>
      localStream?.getVideoTracks().forEach((t) => t.enabled = !off);

  Future<void> switchCamera() async {
    final t = localStream?.getVideoTracks();
    if (t != null && t.isNotEmpty) await Helper.switchCamera(t.first);
  }

  Future<void> hangUp() async {
    try {
      await _doc.update({'ended': true});
    } catch (_) {}
    localStream?.getTracks().forEach((t) => t.stop());
    await localStream?.dispose();
    await _pc?.close();
    await remoteRenderer.dispose();
    await localRenderer.dispose();
  }

  /// Listen for incoming calls in a room.
  static Stream<Map<String, dynamic>?> incoming(String roomId, String myUid) =>
      FirebaseFirestore.instance
          .collection('rooms')
          .doc(roomId)
          .collection('calls')
          .doc('active')
          .snapshots()
          .map((s) {
        final d = s.data();
        if (d == null || d['ended'] == true || d['from'] == myUid || d['answer'] != null) {
          return null;
        }
        return d;
      });
}
