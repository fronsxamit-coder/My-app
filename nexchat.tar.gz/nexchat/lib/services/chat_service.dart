import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'auth_service.dart';

/// Data model
///   users/{uid}                      profile
///   servers/{sid}                    name, owner, members[], inviteCode
///   rooms/{rid}                      type: channel | dm | group, name, members[], serverId?
///   rooms/{rid}/messages/{mid}       text/image/video/file/audio
///   rooms/{rid}/calls/{cid}          WebRTC signalling
class ChatService {
  static final _db = FirebaseFirestore.instance;
  static final _storage = FirebaseStorage.instance;
  static String get uid => AuthService.me.uid;

  // ---------- Servers & channels ----------
  static Stream<QuerySnapshot<Map<String, dynamic>>> myServers() =>
      _db.collection('servers').where('members', arrayContains: uid).snapshots();

  static Future<void> createServer(String name) async {
    final s = _db.collection('servers').doc();
    await s.set({
      'name': name,
      'owner': uid,
      'members': [uid],
      'inviteCode': _code(),
      'createdAt': FieldValue.serverTimestamp(),
    });
    await createChannel(s.id, 'general');
    await createChannel(s.id, 'random');
  }

  static Future<bool> joinServer(String code) async {
    final q = await _db
        .collection('servers')
        .where('inviteCode', isEqualTo: code.trim().toUpperCase())
        .limit(1)
        .get();
    if (q.docs.isEmpty) return false;
    await q.docs.first.reference.update({'members': FieldValue.arrayUnion([uid])});
    return true;
  }

  static Future<void> leaveServer(String sid) =>
      _db.collection('servers').doc(sid).update({'members': FieldValue.arrayRemove([uid])});

  static Future<void> createChannel(String sid, String name) =>
      _db.collection('rooms').add({
        'type': 'channel',
        'serverId': sid,
        'name': name.toLowerCase().replaceAll(' ', '-'),
        'createdAt': FieldValue.serverTimestamp(),
      });

  static Stream<QuerySnapshot<Map<String, dynamic>>> channels(String sid) => _db
      .collection('rooms')
      .where('serverId', isEqualTo: sid)
      .orderBy('createdAt')
      .snapshots();

  // ---------- DMs & groups ----------
  static Stream<QuerySnapshot<Map<String, dynamic>>> myChats() => _db
      .collection('rooms')
      .where('members', arrayContains: uid)
      .orderBy('lastAt', descending: true)
      .snapshots();

  static Future<String> openDm(String otherUid) async {
    final ids = [uid, otherUid]..sort();
    final id = 'dm_${ids.join('_')}';
    final ref = _db.collection('rooms').doc(id);
    if (!(await ref.get()).exists) {
      await ref.set({
        'type': 'dm',
        'members': ids,
        'lastAt': FieldValue.serverTimestamp(),
        'lastText': '',
      });
    }
    return id;
  }

  static Future<String> createGroup(String name, List<String> memberUids) async {
    final ref = _db.collection('rooms').doc();
    await ref.set({
      'type': 'group',
      'name': name,
      'owner': uid,
      'members': {uid, ...memberUids}.toList(),
      'lastAt': FieldValue.serverTimestamp(),
      'lastText': '',
    });
    return ref.id;
  }

  static Future<List<Map<String, dynamic>>> searchUsers(String q) async {
    final s = await _db
        .collection('users')
        .where('name', isGreaterThanOrEqualTo: q)
        .where('name', isLessThan: '$q')
        .limit(20)
        .get();
    return s.docs.where((d) => d.id != uid).map((d) => {...d.data(), 'uid': d.id}).toList();
  }

  // ---------- Messages ----------
  static CollectionReference<Map<String, dynamic>> _msgs(String rid) =>
      _db.collection('rooms').doc(rid).collection('messages');

  static Stream<QuerySnapshot<Map<String, dynamic>>> messages(String rid) =>
      _msgs(rid).orderBy('createdAt', descending: true).limit(100).snapshots();

  static Future<void> send(
    String rid, {
    String text = '',
    String type = 'text',
    String? url,
    String? fileName,
    String? replyTo,
  }) async {
    final u = AuthService.me;
    await _msgs(rid).add({
      'text': text,
      'type': type,
      'url': url,
      'fileName': fileName,
      'replyTo': replyTo,
      'senderId': u.uid,
      'senderName': u.displayName ?? u.email ?? 'User',
      'senderPhoto': u.photoURL,
      'createdAt': FieldValue.serverTimestamp(),
      'reactions': {},
    });
    await _db.collection('rooms').doc(rid).set({
      'lastAt': FieldValue.serverTimestamp(),
      'lastText': type == 'text' ? text : '[$type]',
    }, SetOptions(merge: true));
  }

  static Future<void> deleteMessage(String rid, String mid) =>
      _msgs(rid).doc(mid).delete();

  static Future<void> react(String rid, String mid, String emoji) =>
      _msgs(rid).doc(mid).update({
        'reactions.$emoji': FieldValue.arrayUnion([uid])
      });

  /// Uploads to Firebase Storage (the user's cloud) and returns the URL.
  static Future<String> upload(String rid, File file, String name,
      {void Function(double)? onProgress}) async {
    final ref = _storage
        .ref('rooms/$rid/${DateTime.now().millisecondsSinceEpoch}_$name');
    final task = ref.putFile(file);
    task.snapshotEvents.listen((s) {
      if (s.totalBytes > 0) onProgress?.call(s.bytesTransferred / s.totalBytes);
    });
    await task;
    return ref.getDownloadURL();
  }

  static String _code() {
    const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random.secure();
    return List.generate(6, (_) => c[r.nextInt(c.length)]).join();
  }
}
