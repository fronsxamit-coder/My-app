import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

/// Google login + email/password. All user data lives in Firestore under the
/// account's uid, so logging out or uninstalling never loses anything.
class AuthService {
  static final _auth = FirebaseAuth.instance;
  static final _db = FirebaseFirestore.instance;

  static User get me => _auth.currentUser!;

  static Future<void> signInWithGoogle() async {
    final g = await GoogleSignIn().signIn();
    if (g == null) return; // cancelled
    final ga = await g.authentication;
    final cred = GoogleAuthProvider.credential(
      accessToken: ga.accessToken,
      idToken: ga.idToken,
    );
    final res = await _auth.signInWithCredential(cred);
    await _saveProfile(res.user!);
  }

  static Future<void> registerEmail(String name, String email, String pass) async {
    final res = await _auth.createUserWithEmailAndPassword(email: email, password: pass);
    await res.user!.updateDisplayName(name);
    await _saveProfile(res.user!, nameOverride: name);
  }

  static Future<void> signInEmail(String email, String pass) async {
    final res = await _auth.signInWithEmailAndPassword(email: email, password: pass);
    await _saveProfile(res.user!);
  }

  static Future<void> resetPassword(String email) =>
      _auth.sendPasswordResetEmail(email: email);

  static Future<void> signOut() async {
    await GoogleSignIn().signOut();
    await _auth.signOut();
  }

  static Future<void> _saveProfile(User u, {String? nameOverride}) async {
    final ref = _db.collection('users').doc(u.uid);
    final snap = await ref.get();
    final data = {
      'name': nameOverride ?? u.displayName ?? u.email?.split('@').first ?? 'User',
      'email': u.email,
      'lastSeen': FieldValue.serverTimestamp(),
    };
    if (!snap.exists) {
      data['photo'] = u.photoURL;
      data['createdAt'] = FieldValue.serverTimestamp();
      data['status'] = 'Hey, I use NexChat!';
    }
    await ref.set(data, SetOptions(merge: true));
  }

  static Future<void> updateProfile({String? name, String? status, String? photo}) {
    final data = <String, dynamic>{};
    if (name != null) data['name'] = name;
    if (status != null) data['status'] = status;
    if (photo != null) data['photo'] = photo;
    return _db.collection('users').doc(me.uid).set(data, SetOptions(merge: true));
  }
}
