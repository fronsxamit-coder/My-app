import re, pathlib, sys
a = pathlib.Path("android")

def rd(p): return p.read_text()
def find(*names):
    for n in names:
        p = a / n
        if p.exists(): return p
    sys.exit("missing " + " / ".join(names))

# settings: declare google-services plugin
s = find("settings.gradle.kts", "settings.gradle")
t = rd(s)
if "google-services" not in t:
    kts = s.suffix == ".kts"
    line = ('    id("com.google.gms.google-services") version "4.4.2" apply false\n' if kts
            else '    id "com.google.gms.google-services" version "4.4.2" apply false\n')
    t = re.sub(r'(plugins\s*\{\n)', r'\1' + line, t, count=1, flags=re.M)
    # the last 'plugins {' block is the one with flutter plugins; append inside it
    idx = t.rfind("plugins {")
    if idx != -1 and "google-services" not in t[idx:]:
        t = t[:idx + 9] + "\n" + line + t[idx + 9:]
    s.write_text(t)

# app module: apply plugin + minSdk 23
b = find("app/build.gradle.kts", "app/build.gradle")
t = rd(b)
kts = b.suffix == ".kts"
if "google-services" not in t:
    line = ('    id("com.google.gms.google-services")\n' if kts
            else '    id "com.google.gms.google-services"\n')
    t = t.replace("plugins {\n", "plugins {\n" + line, 1)
t = re.sub(r'minSdk(Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)',
           'minSdk = 23' if kts else 'minSdkVersion 23', t)
b.write_text(t)

# manifest permissions
m = a / "app/src/main/AndroidManifest.xml"
t = rd(m)
perms = ["INTERNET", "CAMERA", "RECORD_AUDIO", "MODIFY_AUDIO_SETTINGS",
         "READ_MEDIA_IMAGES", "READ_MEDIA_VIDEO"]
add = "".join(f'    <uses-permission android:name="android.permission.{p}"/>\n'
              for p in perms if p not in t)
t = re.sub(r'(<manifest[^>]*>\n)', r'\1' + add, t, count=1)
t = t.replace('android:label="nexchat"', 'android:label="NexChat"')
m.write_text(t)
print("patched")
